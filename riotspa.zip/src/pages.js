export default [{
  path: '/',
  label: 'Home',
  componentName: 'home'
}, {
  path: '/about',
  label: 'About',
  componentName: 'about'
}, {
  path: '/info',
  label: 'Info',
  componentName: 'info'
},
 {
  path: '/profile',
  label: 'Profile',
  componentName: 'profile'
},
 {
  path: '/gallery',
  label: 'Gallery',
  componentName: 'gallery'
}]