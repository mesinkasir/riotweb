# RIOT WEBSITE APP

![single page app website free source code download](https://a.fsdn.com/allura/p/riotweb/icon?1612535234&w=90)

themes template for riot single page app, develope modern web using riot

A features

![single page app website free source code download](https://1.bp.blogspot.com/-06T7wjkv0sU/YB1Vt7DFwcI/AAAAAAAAMts/Ps1YOJN1VWsk9jqHZxy5JNgMJUHd2SfWACLcBGAsYHQ/s659/build%2Bsingle%2Bpage%2Bapp%2Bwith%2Briot%2Bfull%2Bsource%2Bcode%2B%25283%2529.png)

Mobile view

![single page app website free source code download](https://1.bp.blogspot.com/-tG4lQ3afBlA/YB1Vt-B9IWI/AAAAAAAAMto/XD5IVEfZnbsUAMrGOM7vTADzzN9ZMJENQCLcBGAsYHQ/s1349/build%2Bsingle%2Bpage%2Bapp%2Bwith%2Briot%2Bfull%2Bsource%2Bcode%2B%25281%2529.png)

Home page

![single page app website free source code download](https://1.bp.blogspot.com/-qYktMJT8C6w/YB1VvdM1uLI/AAAAAAAAMt4/m5PFvckRf2YhzOcGGgvUhYMR0HHy1VG6wCLcBGAsYHQ/s1348/build%2Bsingle%2Bpage%2Bapp%2Bwith%2Briot%2Bfull%2Bsource%2Bcode%2B%25286%2529.png)

About Page

![single page app website free source code download](https://1.bp.blogspot.com/-d1IyrPWD4vk/YB1Vu_iYzbI/AAAAAAAAMt0/66EtrTbcjGk10eST4oZbjN9ZQEt8L8y8wCLcBGAsYHQ/s1349/build%2Bsingle%2Bpage%2Bapp%2Bwith%2Briot%2Bfull%2Bsource%2Bcode%2B%25285%2529.png)

Profile Page

![single page app website free source code download](https://1.bp.blogspot.com/-Lr4IJGUVCck/YB1VuGcHmZI/AAAAAAAAMtw/b-lwHVLVl0MulvVSkDgwkMq9wDTYWatvwCLcBGAsYHQ/s1350/build%2Bsingle%2Bpage%2Bapp%2Bwith%2Briot%2Bfull%2Bsource%2Bcode%2B%25284%2529.png)

Gallery Page

---------------------------------

How to install :

For first we need 
+ node / npm
+ riot

then download this source code

and run npm i && npm start

for documentation installation :

[https://www.hockeycomputindo.com/2021/02/how-to-create-single-app-website-using.html](https://www.hockeycomputindo.com/2021/02/how-to-create-single-app-website-using.html)

or play video installation :

[view video](https://youtu.be/9sWY3KUMBGE)

